/**********************************************************************/
/**********************************************************************/
/*****************		Author:  OMAR YAHYA		***********************/
/*****************		Layer:	 LIB			***********************/
/*****************		Name:	 Interrupt	    ***********************/
/**********************************************************************/
/**********************************************************************/

#ifndef INTERRUPT_H_
#define INTERRUPT_H_

#define INT0_VECT     __vector_1
#define INT1_VECT     __vector_2
#define INT2_VECT     __vector_3
#define INT3_VECT     __vector_4
#define INT4_VECT     __vector_5
#define INT5_VECT     __vector_6
#define INT6_VECT     __vector_7
#define INT7_VECT     __vector_8
#define TIMER1_CAPT   __vector_11
#define TIMER3_CAPT   __vector_25

#define ISR(INT_vect)void INT_vect(void) __attribute__((signal));\
	void INT_vect (void)

#endif
