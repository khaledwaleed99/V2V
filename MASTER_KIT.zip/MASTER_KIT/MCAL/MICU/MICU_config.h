/**********************************************************************************************************************/
/**********************************************************************************************************************/
/*****************		Author:  OMAR YAHYA		***********************************************************************/
/*****************		Layer:	 MCAL			***********************************************************************/
/*****************		SWC:	 ICU			***********************************************************************/
/*****************		File:	 Configuration  ***********************************************************************/
/**********************************************************************************************************************/
/**********************************************************************************************************************/

#ifndef MICU_MICU_CONFIG_H_
#define MICU_MICU_CONFIG_H_

/**
 *  Configure Prescaler:
 *   - NO_CLK --> Means Timer Turned OFF
 *   - FCPU
 *   - PRESCALER_8
 *   - PRESCALER_64
 *   - PRESCALER_256
 *   - PRESCALER_1024
 *   - T0_FALL_EDGE
 *   - T0_RISE_EDGE
 **/

#define MICU1_CLOCK_SELECT  PRESCALER_256
#define MICU3_CLOCK_SELECT  PRESCALER_256

/**
 *  Adjust ICU Noise Canceler:
 *   - NOISE_CANCELER_ENABLED
 *   - NOISE_CANCELER_DISABLED
 */

#define MICU1_NOISE_CANCELER_STATUS NOISE_CANCELER_ENABLED
#define MICU3_NOISE_CANCELER_STATUS NOISE_CANCELER_ENABLED
/**
 *  Select ICU Initial Edge Trigger:
 *  - FALLING_EDGE
 *  - RISING_EDGE
 */

#define MICU1_INITIAL_EDGE RISING_EDGE
#define MICU3_INITIAL_EDGE RISING_EDGE

#endif
