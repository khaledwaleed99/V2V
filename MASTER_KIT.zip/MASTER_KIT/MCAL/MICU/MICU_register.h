/**********************************************************************************************************************/
/**********************************************************************************************************************/
/*****************		Author:  OMAR YAHYA		***********************************************************************/
/*****************		Layer:	 MCAL			***********************************************************************/
/*****************		SWC:	 ICU			***********************************************************************/
/*****************		File:	 Register       ***********************************************************************/
/**********************************************************************************************************************/
/**********************************************************************************************************************/

#ifndef MICU_MICU_REGISTER_H_
#define MICU_MICU_REGISTER_H_

/**********************************************************************************************************************
 *  REGISTERS ADDRESSES
 **********************************************************************************************************************/
#define REG_TCCR1A (*((volatile u8 *)0x4F))  // Timer/Counter 1 Control Register A
#define REG_TCCR1B (*((volatile u8 *)0x4E))  // Timer/Counter 1 Control Register B
#define REG_TCCR3A (*((volatile u8 *)0x8B))  // Timer/Counter 3 Control Register A
#define REG_TCCR3B (*((volatile u8 *)0x8A))  // Timer/Counter 3 Control Register B
#define REG_ICR1   (*((volatile u16*)0x46))  // Timer1 Input Capture Register
#define REG_ICR3   (*((volatile u16*)0x80))  // Timer3 Input Capture Register
#define REG_TIMSK  (*((volatile u8 *)0x57))  // Timer/Counter Interrupt Mask Register
#define REG_ETIMSK (*((volatile u8 *)0x7D))  // Extended Timer/Counter Interrupt Mask Register
#define REG_TIFR   (*((volatile u8 *)0x56))  // Timer/Counter Interrupt Flag Register
#define REG_ETIFR  (*((volatile u8 *)0x7C))  // Extended Timer/Counter Interrupt Flag Register
/**********************************************************************************************************************
 *  REGISTERS BIT NUMBER
 **********************************************************************************************************************/
#define TCCR1A_WGM11  (1) // Timer1 Waveform Generation Mode 1
#define TCCR1A_WGM10  (0) // Timer1 Waveform Generation Mode 0

#define TCCR1B_ICNC1  (7) // Timer1 Input Capture Noise Canceler
#define TCCR1B_ICES1  (6) // Timer1 Input Capture Edge Select
#define TCCR1B_WGM13  (4) // Timer1 Waveform Generation Mode 4
#define TCCR1B_WGM12  (3) // Timer1 Waveform Generation Mode 2
#define TCCR1B_CS12   (2) // Timer1 Clock Select 2
#define TCCR1B_CS11   (1) // Timer1 Clock Select 1
#define TCCR1B_CS10   (0) // Timer1 Clock Select 0

#define TCCR3A_WGM31  (1) // Timer3 Waveform Generation Mode 1
#define TCCR3A_WGM30  (0) // Timer3 Waveform Generation Mode 0

#define TCCR3B_ICNC3  (7) // TIMER3 Input Capture Noise Canceler
#define TCCR3B_ICES3  (6) // TIMER3 Input Capture Edge Select
#define TCCR3B_WGM33  (4) // TIMER3 Waveform Generation Mode 4
#define TCCR3B_WGM32  (3) // TIMER3 Waveform Generation Mode 2
#define TCCR3B_CS32   (2) // TIMER3 Clock Select 2
#define TCCR3B_CS31   (1) // TIMER3 Clock Select 1
#define TCCR3B_CS30   (0) // TIMER3 Clock Select 0

#define TIMSK_TICIE1  (5) // Timer/Counter1, Input Capture Interrupt Enable

#define ETIMSK_TICIE3 (5) // Timer/Counter3 Input Capture Interrupt Enable

#define TIFR_ICF1     (5) // Timer/Counter1, Input Capture Flag

#define ETIFR_ICF3    (5) // Timer/Counter3, Input Capture Flag

#endif
