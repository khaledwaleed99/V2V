/**********************************************************************************************************************/
/**********************************************************************************************************************/
/*****************		Author:  Omar Yahya		***********************************************************************/
/*****************		Layer:	 MCAL			***********************************************************************/
/*****************		SWC:	 DIO			***********************************************************************/
/*****************		File:	 Interface      ***********************************************************************/
/**********************************************************************************************************************/
/**********************************************************************************************************************/

#ifndef MDIO_MDIO_INTERFACE_H_
#define MDIO_MDIO_INTERFACE_H_

/**********************************************************************************************************************
 * SHAREABLE MACROS
 **********************************************************************************************************************/

/**********************************************************************************************************************
 * USER DEFINED DATA TYPES
 **********************************************************************************************************************/
typedef enum {
/// PORTA
	PA0 = 10,
	PA1 = 11,
	PA2 = 12,
	PA3 = 13,
	PA4 = 14,
	PA5 = 15,
	PA6 = 16,
	PA7 = 17,
/// PORTB
	PB0 = 20,
	PB1 = 21,
	PB2 = 22,
	PB3 = 23,
	PB4 = 24,
	PB5 = 25,
	PB6 = 26,
	PB7 = 27,
///PORTC
	PC0 = 30,
	PC1 = 31,
	PC2 = 32,
	PC3 = 33,
	PC4 = 34,
	PC5 = 35,
	PC6 = 36,
	PC7 = 37,
///PORTD
	PD0 = 40,
	PD1 = 41,
	PD2 = 42,
	PD3 = 43,
	PD4 = 44,
	PD5 = 45,
	PD6 = 46,
	PD7 = 47,
///PORTE
	PE0 = 50,
	PE1 = 51,
	PE2 = 52,
	PE3 = 53,
	PE4 = 54,
	PE5 = 55,
	PE6 = 56,
	PE7 = 57,
///PORTF
	PF0 = 60,
	PF1 = 61,
	PF2 = 62,
	PF3 = 63,
	PF4 = 64,
	PF5 = 65,
	PF6 = 66,
	PF7 = 67,
///PORTG
	PG0 = 70,
	PG1 = 71,
	PG2 = 72,
	PG3 = 73,
	PG4 = 74,
} Pin_t;

typedef enum {
	PORTA = 1, PORTB = 2, PORTC = 3, PORTD = 4, PORTE = 5, PORTF = 6, PORTG = 7
} Port_t;

typedef enum {
	PORT_OUTPUT = 0xFF, PORT_INPUT = 0x00
} PortDirection_t;

typedef enum {
	PORT_HIGH = 0xFF, PORT_LOW = 0x00
} PortValue_t;

typedef enum {
	INPUT = 0, OUTPUT = 1
} Direction_t;

typedef enum {
	LOW = 0, HIGH = 1
} Value_t;
/**********************************************************************************************************************
 * GLOBAL FUNCTIONS PROTOTYPES
 **********************************************************************************************************************/

/**
* Input:  		 1- MC Pin from PA0 --> PG4
* 				 2- Direction for Pin:
* 				 	- INPUT
* 				 	- OUTPUT
* Output: 		 No Output
* In/Out: 		 No In/Out
* Description:   This function adjust the Pin Direction
*/
ErrorState_t MDIO_enSetPinDirection(Pin_t copy_enPin, Direction_t copy_enDirection);

/**
* Input:  		 1- MC Port From PORTA --> PORTG
* 				 2- Direction for Port:
* 				 	- PORT_OUTPUT
* 				 	- PORT_INPUT
* Output: 		 No Output
* In/Out: 		 No In/Out
* Description:   This function adjust the Port Direction
*/
ErrorState_t MDIO_enSetPortDirection(Port_t copy_enPort, u8 copy_u8Value);

/**
* Input:  		 1- MC Pin from PA0 --> PG4
* 				 2- Value for Pin:
* 				 	- LOW
* 				 	- HIGH
* Output: 		 No Output
* In/Out: 		 No In/Out
* Description:   This function adjust Pin Value
*/
ErrorState_t MDIO_enSetPinValue(Pin_t copy_enPin, Value_t copy_enValue);

/**
* Input:         1- MC Port From PORTA --> PORTG
* 				 2- Value from 0 to 255 or PORT_HIGH | PORT_LOW
* Output: 		 No Output
* In/Out: 		 No In/Out
* Description:   This function adjust Port Value
*/
ErrorState_t MDIO_enSetPortValue(Port_t copy_enPort, u8 copy_u8Value);

/**
* Input:  		 MC Pin from PA0 --> PG4
* Output: 		 Pin Value --> LOW or HIGH
* In/Out: 		 No In/Out
* Description:   This function return The value for certain Pin
*/
ErrorState_t MDIO_enGetPinValue(Pin_t copy_enPin, Value_t *ptrPinValue);

/**
* Input:  		 MC Port From PORTA --> PORTG
* Output: 		 Port Value --> 0 to 255
* In/Out: 		 No In/Out
* Description:   This function return the whole Port Value
*/
ErrorState_t MDIO_enGetPortValue(Port_t copy_enPort, u8 *ptrPortValue);

/**
* Input:  		 MC Pin from PA0 --> PG4
* Output: 		 No Output
* In/Out: 		 No In/Out
* Description:   This function Toggle certain Pin
*/
ErrorState_t MDIO_enTogglePinValue(Pin_t copy_enPin);

/**
* Input:  		 MC Port From PORTA --> PORTG
* Output: 		 No Output
* In/Out: 		 No In/Out
* Description:   This function Toggle the whole Port
*/
ErrorState_t MDIO_enTogglePortValue(Port_t copy_enPort);

#endif
