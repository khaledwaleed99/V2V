/*
 * NRF.c
 *
 * Created: 12/14/2023 12:13:03 AM
 *  Author: User
 */

#define  F_CPU  8000000

#include "NRF.h"
#include "STD_TYPES.h"
#include "util/delay.h"

static uint8 rx_address[5] = { 0xe7, 0xe7, 0xe7, 0xe7, 0xe7 }; /* Read pipe address */
static uint8 tx_address[5] = { 0xe7, 0xe7, 0xe7, 0xe7, 0xe7 }; /* Write pipe address */

void NRF_CSN_SELECT(void) {
	DIO_SET_PIN_VALUE(CSN_PORT, CSN_PIN, DIO_LOW);
}

void NRF_CSN_UNSELECT(void) {
	DIO_SET_PIN_VALUE(CSN_PORT, CSN_PIN, DIO_HIGH);
}

void NRF_CE_ENABLE(void) {
	DIO_SET_PIN_VALUE(CE_PORT, CE_PIN, DIO_HIGH);
}

void NRF_CE_DISABLE(void) {
	DIO_SET_PIN_VALUE(CE_PORT, CE_PIN, DIO_LOW);
}

uint8 NRF_SEND_SPI(uint8 REG_ADDRESS, void *DATA, uint32 LENGHT) {
	uint8 COUNTER;
	uint8 LOCAL_STATUS;

	NRF_CSN_SELECT();

	LOCAL_STATUS = SPI_SEND_RECEIVE(REG_ADDRESS);

	for (COUNTER = 0; COUNTER < LENGHT; COUNTER++) {
		(((uint8*) DATA)[COUNTER]) = SPI_SEND_RECEIVE(((uint8*) DATA)[COUNTER]);
	}
	NRF_CSN_UNSELECT();

	return LOCAL_STATUS;
}

uint8 NRF_WRITE_REG(uint8 REG_ADDRESS, void *DATA, uint32 LENGHT) {
	return NRF_SEND_SPI((W_REGISTER | REG_ADDRESS), DATA, LENGHT);
}

uint8 NRF_READ_RED(uint8 REG_ADDRESS, void *DATA, uint32 LENGHT) {
	return NRF_SEND_SPI((R_REGISTER | REG_ADDRESS), DATA, LENGHT);
}

void NRF_INIT(void) {
	uint8 check, data;

	DIO_SET_PIN_DIREC(CE_PORT, CE_PIN, DIO_OUTPUT);

	DIO_SET_PIN_DIREC(CSN_PORT, CSN_PIN, DIO_OUTPUT);

	/* DISABLING THE NRF BEFORE CONFIG */

	NRF_CSN_UNSELECT();
	NRF_CE_DISABLE();

	/* SPI INIT */

	SPI_INT();

	_delay_ms(100);

	data = (!(RX_INTERRUPT) << MASK_RX_DR) | /* IRQ interrupt on RX (0 = enabled) */
	(!(TX_INTERRUPT) << MASK_TX_DS) | /* IRQ interrupt on TX (0 = enabled) */
	(!(RT_INTERRUPT) << MASK_MAX_RT) | /* IRQ interrupt on auto retransmit counter overflow (0 = enabled) */
	(1 << EN_CRC) | /* CRC enable */
	(1 << CRC0) | /* CRC scheme 2 bytes */
	(1 << PWR_UP) | /* Power up  */
	(1 << PRIM_RX);

	NRF_WRITE_REG(CONFIG, &data, 1);
	NRF_READ_RED(CONFIG, &check, 1);

	data = (AUTO_ACK << ENAA_P5) | (AUTO_ACK << ENAA_P4) | (AUTO_ACK << ENAA_P3)
			| (AUTO_ACK << ENAA_P2) | (AUTO_ACK << ENAA_P1)
			| (AUTO_ACK << ENAA_P0);

	NRF_WRITE_REG(EN_AA, &data, 1);
	NRF_READ_RED(EN_AA, &check, 1);

	data = 0xF0; /* Delay 4000us with 1 retry */

	NRF_WRITE_REG(SETUP_RETR, &data, 1);
	NRF_READ_RED(SETUP_RETR, &check, 1);

	/* Disable RX addresses */
	data = 0;

	NRF_WRITE_REG(EN_RXADDR, &data, 1);
	NRF_READ_RED(EN_RXADDR, &check, 1);

	/* Set channel */
	data = CHANNEL;

	NRF_WRITE_REG(RF_CH, &data, 1);
	NRF_READ_RED(RF_CH, &check, 1);

	data = (CONTINUOUS << CONT_WAVE) | /* Continuous carrier transmit */
	((DATARATE >> RF_DR_HIGH) << RF_DR_HIGH) | /* Data rate */
	((POWER >> RF_PWR) << RF_PWR); /* PA level */

	NRF_WRITE_REG(RF_SETUP, &data, 1);
	NRF_READ_RED(RF_SETUP, &check, 1);

	/* Status Clear */
	data = (1 << RX_DR) | (1 << TX_DS) | (1 << MAX_RT);

	NRF_WRITE_REG(STATUS, &data, 1);
	NRF_READ_RED(STATUS, &check, 1);

	/* Dynamic payload on all pipes */
	data = (DYN_PAYLOAD << DPL_P0) | (DYN_PAYLOAD << DPL_P1)
			| (DYN_PAYLOAD << DPL_P2) | (DYN_PAYLOAD << DPL_P3)
			| (DYN_PAYLOAD << DPL_P4) | (DYN_PAYLOAD << DPL_P5);

	NRF_WRITE_REG(DYNPD, &data, 1);
	NRF_READ_RED(DYNPD, &check, 1);

	NRF_SEND_SPI(ACTIVATE, 0, 0);
	NRF_SEND_SPI(POSTACTIVATE, 0, 0);

	/* Enable dynamic payload */

	data = (DYN_PAYLOAD << EN_DPL) | (AUTO_ACK << EN_ACK_PAY)
			| (!AUTO_ACK << EN_DYN_ACK);

	NRF_WRITE_REG(FEATURE, &data, 1);
	NRF_READ_RED(FEATURE, &check, 1);

	/* flush tx,rx */

	NRF_WRITE_REG(FLUSH_RX, 0, 0);
	NRF_WRITE_REG(FLUSH_TX, 0, 0);

	/* open pipes */

	NRF_WRITE_REG(RX_ADDR_P0 + READ_PIPE, rx_address, 5);
	NRF_WRITE_REG(TX_ADDR, tx_address, 5);
	NRF_WRITE_REG(EN_RXADDR, &data, 1);

	/* Enable Pipe */
	data = (1 << READ_PIPE);

	NRF_WRITE_REG(EN_RXADDR, &data, 1);
	NRF_READ_RED(EN_RXADDR, &check, 1);
}

void NRF_OPERATION_MODE(uint8 MODE) {
	uint8 CONFIG_REG, DATA;

	NRF_READ_RED(CONFIG, &CONFIG_REG, 1);

	switch (MODE)

	{
	case POWERUP:

		DATA = CONFIG_REG | (1 << PWR_UP);

		NRF_WRITE_REG(CONFIG, &DATA, 1);

		_delay_ms(2);

		break;

	case POWERDOWN:

		DATA = CONFIG_REG & ~(1 << PWR_UP);

		NRF_WRITE_REG(CONFIG, &DATA, 1);

		break;

	case RECEIVE:

		DATA = CONFIG_REG | (1 << PRIM_RX);

		NRF_WRITE_REG(CONFIG, &DATA, 1);

		DATA = (1 << RX_DR) | (1 << TX_DS) | (1 << MAX_RT);

		NRF_WRITE_REG(STATUS, &DATA, 1);

		break;

	case TRANSMIT:

		DATA = CONFIG_REG & ~(1 << PRIM_RX);

		NRF_WRITE_REG(CONFIG, &DATA, 1);

		break;

	case STANDBY1:
		NRF_CE_DISABLE();
		break;
	case STANDBY2:
		DATA = CONFIG_REG & ~(1 << PRIM_RX);
		NRF_WRITE_REG(CONFIG, &DATA, 1);
		DIO_SET_PIN_VALUE(CE_PORT, CE_PIN, DIO_HIGH);
		_delay_us(150);
		break;
	}
}

void NRF_START_LISTENING(void) {
	NRF_OPERATION_MODE(RECEIVE);
	NRF_CE_ENABLE();
	_delay_us(150);

}

uint8 NRF_AVAILABLE(void) {
	uint8 CONFIG_REG;

	NRF_READ_RED(FIFO_STATUS, &CONFIG_REG, 1);

	if (!(CONFIG_REG & (1 << RX_EMPTY))) {
		return 1;
	}

	else {
		return 0;
	}
}

void NRF_SEND_ACK(void) {
	const void *ack = "A";

	uint8 LENGTH = 1;

	NRF_CSN_SELECT();

	SPI_SEND_RECEIVE(W_ACK_PAYLOAD);

	while (LENGTH--) {
		SPI_SEND_RECEIVE(*(uint8_t*) ack++);
	}

	NRF_CSN_UNSELECT();
}

uint8 NRF_SEND_MESSAGE(const void *tx_message, uint8 Length) {
	NRF_OPERATION_MODE(TRANSMIT);

	NRF_WRITE_REG(FLUSH_RX, 0, 0);

	NRF_WRITE_REG(FLUSH_TX, 0, 0);

	uint8 DATA = (1 << TX_DS);

	NRF_WRITE_REG(STATUS, &DATA, 1);

	/* Disable interrupt on RX */

	NRF_READ_RED(CONFIG, &DATA, 1);

	DATA |= (1 << MASK_RX_DR);

	NRF_WRITE_REG(CONFIG, &DATA, 1);

	NRF_CSN_SELECT();

	if (AUTO_ACK) {
		SPI_SEND_RECEIVE(W_TX_PAYLOAD);
	} else {
		SPI_SEND_RECEIVE(W_TX_PAYLOAD_NOACK);
	}

	while (Length--) {
		SPI_SEND_RECEIVE(*(uint8_t*) tx_message++);
	}

	SPI_SEND_RECEIVE(0);

	NRF_CSN_UNSELECT();

	NRF_CE_ENABLE();

	_delay_us(15);

	NRF_CE_DISABLE();

	NRF_READ_RED(STATUS, &DATA, 1);

	while (!(DATA & (1 << TX_DS)))
		NRF_READ_RED(STATUS, &DATA, 1);

	NRF_READ_RED(CONFIG, &DATA, 1);
	DATA &= ~(1 << MASK_RX_DR);
	NRF_WRITE_REG(CONFIG, &DATA, 1);

	return 1;
}

const char* NRF_READ_MESSAGE(void) {
	static char rx_message[32];

	for (uint8 i = 0; i < 32; i++)
		rx_message[i] = 0;
	if (AUTO_ACK)
		NRF_SEND_ACK();

	uint8 data;
	NRF_READ_RED(R_RX_PL_WID, &data, 1);
	if (data > 0)
		NRF_SEND_SPI(R_RX_PAYLOAD, &rx_message, data + 1);

	uint8 strlen = 0;
	for (uint8 i = 0; rx_message[i] != 0; i++)
		strlen++;
	if (strlen > 0) {
		// Clear RX interrupt
		data = (1 << RX_DR);
		NRF_WRITE_REG(STATUS, &data, 1);

		return rx_message;
	}
	data = (1 << RX_DR);
	NRF_WRITE_REG(STATUS, &data, 1);

	return 0;
}
