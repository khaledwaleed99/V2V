/**********************************************************************************************************************/
/**********************************************************************************************************************/
/*****************		Author:  OMAR YAHYA		***********************************************************************/
/*****************		Layer:	 HAL			***********************************************************************/
/*****************		SWC:	 LCD	        ***********************************************************************/
/*****************		File:	 Configuration  ***********************************************************************/
/**********************************************************************************************************************/
/**********************************************************************************************************************/

#ifndef HLCD_HLCD_CONFIG_H_
#define HLCD_HLCD_CONFIG_H_

/**
 *  Choose LCD Type:
 *  	HLCD_2X16_LCD
 *		HLCD_4X20_LCD
 */

#define HLCD_TYPE HLCD_2X16_LCD

/**
 *  Choose LCD Data Connection:
 *  	HLCD_DATA_PINS
 *		HLCD_DATA_PORT
 */

#define HLCD_DATA HLCD_DATA_PINS

/**
 *  Choose LCD Mode:
 *  	HLCD_8BIT_MODE
 *		HLCD_4BIT_MODE
 * Note: 4-Bit Mode Can't Work with HLCD_DATA_PORT
 */

#define HLCD_MODE HLCD_8BIT_MODE

/**
 *  Configure Pin Connection:
 * Note: If any Pin is Hardware Connected Select -> HLCD_PIN_HARDWARE_CONNECTED
 */

/** Control Pins **/
#define HLCD_RS_PIN PB5
#define HLCD_RW_PIN PB6
#define HLCD_EN_PIN PB7

/** Data Pins **/
#if((HLCD_DATA == HLCD_DATA_PORT) && (HLCD_MODE != HLCD_4BIT_MODE))
#define HLCD_D_PORT PORTA
#elif(HLCD_DATA == HLCD_DATA_PINS)
#if(HLCD_MODE != HLCD_4BIT_MODE)
#define HLCD_D0_PIN PC0
#define HLCD_D1_PIN PC1
#define HLCD_D2_PIN PC2
#define HLCD_D3_PIN PC3
#endif
#define HLCD_D4_PIN PC4
#define HLCD_D5_PIN PC5
#define HLCD_D6_PIN PC6
#define HLCD_D7_PIN PC7
#else
#error ("Wrong LCD Configuration !!")
#endif

/**
 *  Configure Writing Delay  --> Time Taken to Write Character in a String
 *  Configure Overflow Delay --> Time Taken if the Entire LCD Overflowed and Cleared to Continue Writing
 */

#define HLCD_WRITING_DELAY  0
#define HLCD_OVERFLOW_DELAY 500

#endif
