/**********************************************************************************************************************/
/**********************************************************************************************************************/
/*****************		Author:  OMAR YAHYA		***********************************************************************/
/*****************		Layer:	 HAL			***********************************************************************/
/*****************		SWC:	 UltraSonic		***********************************************************************/
/*****************		File:	 Program        ***********************************************************************/
/**********************************************************************************************************************/
/**********************************************************************************************************************/

/**********************************************************************************************************************
 *  INCLUDES
 **********************************************************************************************************************/
#include "avr/delay.h"
#include "STD_TYPES.h"
#include "ERROR_STATES.h"
#include "MDIO_interface.h"
#include "MICU_interface.h"
#include "HULTRASONIC_private.h"
#include "HULTRASONIC_config.h"
#include "HULTRASONIC_interface.h"
/**********************************************************************************************************************
 *  LOCAL DATA
 **********************************************************************************************************************/

/**********************************************************************************************************************
 *  GLOBAL DATA
 **********************************************************************************************************************/
ICU_t Global_enICU;
u16 Global_u16Reading1 = 0;
u16 Global_u16Reading2 = 0;
u16 Global_u16Ticks;
f32 Global_f32Time;
u16 Global_u16Distance;
/**********************************************************************************************************************
 *  LOCAL FUNCTIONS
 **********************************************************************************************************************/
static void HULTRASONIC_voidCallBackICU() {
	static u8 Local_u8Counter = 0;
	Local_u8Counter++;
	if (Local_u8Counter == 1) {
		MICU_enReadICR(Global_enICU, &Global_u16Reading1);
		MICU_enEdgeSelect(Global_enICU, FALLING);
	} else if (Local_u8Counter == 2) {
		MICU_enReadICR(Global_enICU, &Global_u16Reading2);
		MICU_enEdgeSelect(Global_enICU, RISING);
		Local_u8Counter = 0;
	}
}
/**********************************************************************************************************************
 *  GLOBAL FUNCTIONS
 **********************************************************************************************************************/
ErrorState_t HULTRASONIC_enInit(ICU_t copy_enICU, Pin_t copy_enTrigger) {
	ErrorState_t Local_enState = SUCCESS;
	/** Set Trigger Pin as Output **/
	MDIO_enSetPinDirection(copy_enTrigger, OUTPUT);
	/** Set Echo Pin as Input **/
	if (copy_enICU == ICU1) {
		MDIO_enSetPinDirection(ICP1_PIN, INPUT);
	} else if (copy_enICU == ICU3) {
		MDIO_enSetPinDirection(ICP3_PIN, INPUT);
	} else {
		Local_enState = OUT_OF_RANGE;
	}
	MICU_enSetCallBack(copy_enICU, HULTRASONIC_voidCallBackICU);
	MICU_enInterruptEnable(copy_enICU);
	MICU_enInit(copy_enICU);
	return Local_enState;
}

ErrorState_t HULTRASONIC_enGetReading(ICU_t copy_enICU, Pin_t copy_enTrigger, u16 *ptrDistance) {
	ErrorState_t Local_enState = SUCCESS;
	if (ptrDistance == NULL) {
		Local_enState = NULL_POINTER;
	} else {
		/** Move the ICU source to Pass it to Callback Function **/
		Global_enICU = copy_enICU;
		/** Send Trigger Pulse **/
		MDIO_enSetPinValue(copy_enTrigger, HIGH);
		_delay_us(10);
		MDIO_enSetPinValue(copy_enTrigger, LOW);
		/** Busy Waiting until all Reading finished **/
		while (Global_u16Reading2 == 0)
			;
		Global_u16Ticks = Global_u16Reading2 - Global_u16Reading1;
		Global_f32Time = (f32) Global_u16Ticks * ((f32) ICU_PRESCALER / (f32) ICU_FCPU);
		*ptrDistance = Global_f32Time / 58.0;
		/** Return Global Reading to its Initial Value to Busy wait again if this function called again **/
		Global_u16Reading1 = 0;
		Global_u16Reading2 = 0;
	}
	return Local_enState;
}
