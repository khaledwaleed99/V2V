/**********************************************************************************************************************/
/**********************************************************************************************************************/
/*****************		Author:  OMAR YAHYA		***********************************************************************/
/*****************		Layer:	 HAL			***********************************************************************/
/*****************		SWC:	 UltraSonic		***********************************************************************/
/*****************		File:	 Interface      ***********************************************************************/
/**********************************************************************************************************************/
/**********************************************************************************************************************/

#ifndef HULTRASONIC_HULTRASONIC_INTERFACE_H_
#define HULTRASONIC_HULTRASONIC_INTERFACE_H_

/**********************************************************************************************************************
 * SHAREABLE MACROS
 **********************************************************************************************************************/

/**********************************************************************************************************************
 * USER DEFINED DATA TYPES
 **********************************************************************************************************************/

/**********************************************************************************************************************
 * GLOBAL FUNCTIONS PROTOTYPES
 **********************************************************************************************************************/

/**
 * Input:  		 1- ICU Select:
 * 				 	- ICU1
 * 				 	- ICU3
 * 				 2- Pin select for Trigger from PA0 to PG4
 * Output: 		 No Output
 * In/Out: 		 No In/Out
 * Description:  This function Initialize the UltraSonic by:
 * 				 	- Set Trigger Pin as Output
 * 				 	- Set Echo Pin as Input
 * 				 	- Set Callback for ICU
 * 				 	- Enable the ICU Interrupt
 * 				 	- Initialize the ICU
 * Pre-request:	 Enable GIE after calling this function
 */
ErrorState_t HULTRASONIC_enInit(ICU_t copy_enICU, Pin_t copy_enTrigger);

/**
 * Input:  		 1- ICU Select:
 * 				 	- ICU1
 * 				 	- ICU3
 * 				 2- Pin select for Trigger from PA0 to PG4
 * Output: 		 The Measured Distance
 * In/Out: 		 No In/Out
 * Description:  This function Get the Reading from the UltraSonic
 */
ErrorState_t HULTRASONIC_enGetReading(ICU_t copy_enICU, Pin_t copy_enTrigger, u16 *ptrDistance);

#endif
