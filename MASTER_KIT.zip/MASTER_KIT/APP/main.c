/*
 * main.c
 *
 *  Created on: Dec 3, 2023
 *      Author: OMAR YAHYA
 */

#include "avr/delay.h"
#include "STD_TYPES.h"
#include "ERROR_STATES.h"
#include "MDIO_interface.h"
#include "MGIE_Interface.h"
#include "MICU_interface.h"
#include "HLCD_interface.h"
#include "HULTRASONIC_interface.h"
#include "NRF.h"

void main(void) {
	u16 Local_u16Distance1;
	/** Turn OFF 7 Segments **/
	MDIO_enSetPinValue(PF2, HIGH);
	/** Adjust LCD Back light **/
	MDIO_enSetPinDirection(PE4, OUTPUT);
	MDIO_enSetPinValue(PE4, HIGH);
	/**  LEDs **/
	MDIO_enSetPinDirection(PF1, OUTPUT);
	MDIO_enSetPinValue(PF1, HIGH);
	MDIO_enSetPinDirection(PA4, OUTPUT);
	MDIO_enSetPinDirection(PA5, OUTPUT);
	MDIO_enSetPinDirection(PA6, OUTPUT);
	MDIO_enSetPinDirection(PA7, OUTPUT);
	HLCD_enInit();
	HULTRASONIC_enInit(ICU1, PA0);
	MGIE_enEnable();
	/** NRF **/
	NRF_INIT();
	while (1) {
		HULTRASONIC_enGetReading(ICU1, PA0, &Local_u16Distance1);
		HLCD_enClearDisplay();
		HLCD_enSendString("Distance 1 = ");
		HLCD_enSendIntegerNumber(Local_u16Distance1);
		_delay_ms(1000);
		if (Local_u16Distance1 > 120) {
			NRF_SEND_MESSAGE("z", 1);
			MDIO_enSetPinValue(PA5, HIGH);
		} else if (Local_u16Distance1 > 35) {
			NRF_SEND_MESSAGE("l", 1);
			MDIO_enSetPinValue(PA4, HIGH);
		} else if (Local_u16Distance1 > 15) {
			NRF_SEND_MESSAGE("L", 1);
			MDIO_enSetPinValue(PA7, HIGH);
		} else {
			NRF_SEND_MESSAGE("r", 1);
			MDIO_enSetPinValue(PA6, HIGH);
		}
	}
}
