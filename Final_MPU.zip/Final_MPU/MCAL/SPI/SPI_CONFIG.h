/*
 * SPI_CONFIG.h
 *
 * Created: 11/27/2023 10:02:39 PM
 *  Author: khaled waleed
 */ 


#ifndef SPI_CONFIG_H_
#define SPI_CONFIG_H_

#include "../../LIB/ATMEGA_128_REGS.h"
#include "../../LIB/BIT_MATH.h"



// PINS LAYOUT

#define SPI_Port                DIO_PORTB
#define SlaveSelect             DIO_PIN0
#define ClockSelect             DIO_PIN1
#define MOSI                    DIO_PIN2
#define MISO                    DIO_PIN3


// REG NEEDED BITS 

#define SPIE 7
#define SPE	 6
#define DORD 5
#define MSTR 4
#define CPOL 3
#define CPHA 2
#define SPR1 1
#define SPR0 0

#define SPIF 7



#endif /* SPI_CONFIG_H_ */
