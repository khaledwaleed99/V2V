/*
 * SPI_PROTOTYPES.h
 *
 * Created: 11/27/2023 10:01:56 PM
 *  Author: khaled waleed
 */ 


#ifndef SPI_PROTOTYPES_H_
#define SPI_PROTOTYPES_H_

#include "SPI_CONFIG.h"

void SPI_MASTER_INIT(void);

void SPI_MASTER_TRANSMIT(uint8 Data);

uint8 SPI_MASTER_RECIEVE(void);

void SPI_SLAVE_INIT(void);

uint8 SPI_SLAVE_RECIEVE(void);

void SPI_SLAVE_TRANSMIT(uint8 Data);



#endif /* SPI_PROTOTYPES_H_ */