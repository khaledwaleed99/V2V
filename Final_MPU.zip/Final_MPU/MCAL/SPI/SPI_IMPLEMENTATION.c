/*
 * SPI_IMPLEMENTATION.c
 *
 * Created: 11/27/2023 10:00:07 PM
 *  Author: khaled waleed
 */ 

#include "SPI_PROTOTYPES.h"
#include "../DIO/DIO_PROTOTYPES.h"


void SPI_MASTER_INIT(void)
{
	////////////////SET PINS DIRECTION////////////////////////
	DIO_SET_PIN_DIREC (SPI_Port, SlaveSelect ,DIO_OUTPUT);
	DIO_SET_PIN_DIREC (SPI_Port, ClockSelect  ,DIO_OUTPUT);
	DIO_SET_PIN_DIREC (SPI_Port, MOSI ,DIO_OUTPUT);
	DIO_SET_PIN_DIREC (SPI_Port, MISO ,DIO_INPUT);
	///////////////SET PIN SLAVE SELECT HIGH////////////////////
	DIO_SET_PIN_VALUE (SPI_Port , SlaveSelect ,DIO_HIGH);
	////////////////////ENABLE SPI in MASTER MODE////////////
	DIO_SET_PIN_VALUE (SPCR , SPE ,DIO_HIGH); /////////ENABLE SPI
	DIO_SET_PIN_VALUE (SREG , 7 ,DIO_HIGH);/////////ENABLE GLOBAL INTERRUPT
	DIO_SET_PIN_VALUE (SPCR , SPIE ,DIO_HIGH);//////ENABLE SPI interrupt
	
	DIO_SET_PIN_VALUE (SPCR , MSTR ,DIO_HIGH); //////select master
	/////////////////CHOOSING PRESCALER /4 /////////////////
	DIO_SET_PIN_VALUE (SPCR , SPR0 ,DIO_LOW);
	DIO_SET_PIN_VALUE (SPCR , SPR1 ,DIO_LOW);
}

void SPI_MASTER_TRANSMIT(uint8 Data)
{
	/* Start transmission */
	SPDR = Data;
	/* Wait for transmission complete */
	while(!(SPSR & (1<<SPIF))) ;
	volatile uint8 FlushBuffer =	SPDR;
}
uint8 SPI_MASTER_RECIEVE(void)
{
	/* Wait for reception complete */
	while(!(SPSR & (1<<SPIF)))
	;
	/* Return data register */
	return SPDR;
	
}
void SPI_SLAVE_INIT(void)
{
	////////////////SET PINS DIRECTION////////////////////////
	
	DIO_SET_PIN_DIREC (SPI_Port, SlaveSelect ,DIO_INPUT);
	DIO_SET_PIN_DIREC (SPI_Port, ClockSelect  ,DIO_INPUT);
	DIO_SET_PIN_DIREC (SPI_Port, MOSI ,DIO_INPUT);
	DIO_SET_PIN_DIREC (SPI_Port, MISO ,DIO_OUTPUT);
	
	////////////////////ENABLE SPI in SLAVE MODE////////////
	
	DIO_SET_PIN_VALUE (SPCR , SPE ,DIO_HIGH); //ENABLE SPI
	
	DIO_SET_PIN_VALUE (SREG , 7 ,DIO_HIGH);   //ENABLE GLOBAL INTERRUPT
	
	DIO_SET_PIN_VALUE (SPCR , SPIE ,DIO_HIGH);//////ENABLE SPI interrupt
	DIO_SET_PIN_VALUE (SPCR , MSTR ,DIO_LOW); //////select SLAVE
	/////////////////CHOOSING PRESCALER /4 /////////////////
	
	DIO_SET_PIN_VALUE (SPCR , SPR0 ,DIO_LOW);
	DIO_SET_PIN_VALUE (SPCR , SPR1 ,DIO_LOW);
}
void SPI_SLAVE_TRANSMIT(uint8 Data)
{
	//TO SEND DATA YOU MUST NOTIFY THE MASTER USING DIO PIN///////
	DIO_SET_PIN_DIREC (DIO_PORTA, 0 ,DIO_OUTPUT);///TO NOTIFY
	DIO_SET_PIN_VALUE(DIO_PORTA,0,DIO_HIGH);
	SPDR = Data;//WRITE DATA
	/* Wait for transmission complete */
	while(!(SPSR & (1<<SPIF))) ;
	volatile uint8 FlushBuffer =	SPDR;
}
uint8 SPI_SLAVE_RECIEVE(void)
{
	/* Wait for reception complete */
	while(!(SPSR & (1<<SPIF)))
	;
	/* Return data register */
	return SPDR;
}
