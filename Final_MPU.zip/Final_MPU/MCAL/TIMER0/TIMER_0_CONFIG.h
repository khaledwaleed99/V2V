/*
 * TIMER_0_CONFIG.h
 *
 * Created: 11/27/2023 9:13:49 PM
 *  Author: khaled waleed
 */ 


#ifndef TIMER_0_CONFIG_H_
#define TIMER_0_CONFIG_H_

#include "../../LIB/ATMEGA_128_REGS.h"
#include "../../LIB/BIT_MATH.h"

/*
MACROS FOR THE TIMER'S MODES OF OPERATION 
*/

#define TIMER_0_NORMAL_MODE                          0
#define TIMER_0_PWM_MODE                             1
#define TIMER_0_CTC_MODE                             2           
#define TIMER_0_FAST_PWM_MODE                        3


#define TIMER_0_FAST_PWM_MODE_NON_INVERTED           4
#define TIMER_0_FAST_PWM_MODE_INVERTED               5

#define TIMER_0_PHASE_CORRECT_PWM_MODE_NON_INVERTED  6
#define TIMER_0_PHASE_CORRECT_PWM_MODE_INVERTED      7


// PWM PIN

#define TIMER_0_DIO_PORT                           DIO_PORTB
#define TIMER_0_DIO_PIN                            DIO_PIN4



/*
 THE VALUES BY WHICH THE PRE-SCALLER WILL DIVIDE THE CLOCK FREQU. IN ORDER TO HAVE A LARGER TIME RANGE
 
 KEEP IN MIND THAT SELECTING THE PRE_SCALLER VALUE FOR THE PWM MODE ( FAST , PHASE CORRECT ) IS BASED ON THE FREQUNECY OF THE WAVE NEEDED
*/

#define TIMER_0_PRE_SCALLER_DIV_NO       0
#define TIMER_0_PRE_SCALLER_DIV_8        8
#define TIMER_0_PRE_SCALLER_DIV_64       64
#define TIMER_0_PRE_SCALLER_DIV_256      256
#define TIMER_0_PRE_SCALLER_DIV_1024     1024

/*
FOR STATING THE STATE OF TIMER_0 INTERRUPT
*/

#define   TIMER_0_INTERRUPT_DISABLE   0
#define   TIMER_0_INTERRUPT_ENEBLE    1


#define TIMER_0_MODE_OF_OPERATION              TIMER_0_CTC_MODE  

#define TIMER_0_PRE_SCALLER_VALUE              TIMER_0_PRE_SCALLER_DIV_1024 

#define TIMER_0_INTERRUPT_STATE                TIMER_0_INTERRUPT_ENEBLE

#define TIMER_0_FAST_PWM_STATE                 TIMER_0_FAST_PWM_MODE_NON_INVERTED

#define TIMER_0_PWM_MODE_STATE                 TIMER_0_PHASE_CORRECT_PWM_MODE_NON_INVERTED



#endif /* TIMER_0_CONFIG_H_ */
