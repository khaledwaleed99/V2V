/*===================================================================================================*/
/*  File        : ADC_Interface.h                                                                    */
/*  Description : This interface file includes ADC Driver prototypes and declarations for Atmega32   */
/*  Author      : Mona Elsaied                                                                       */
/*  Date        : 20/10/2023                                                                         */
/*===================================================================================================*/

/* File Gaurd by ifndef & endif */
#ifndef ADC_PROTOTYPES_H
#define ADC_PROTOTYPES_H

/*     Macros of Channel Number    */
#define     ADC0                    0
#define     ADC1                    1
#define     ADC2                    2
#define     ADC3                    3
#define     ADC4                    4
#define     ADC5                    5
#define     ADC6                    6
#define     ADC7                    7

/************************************************************************************************/
/* Function Name : ADC_voidInit                                                                 */
/* Description : Initilization of ADC with Specific Specs accordig to Gonfigration File.h       */
/* Fun. Return : void                                                                           */
/************************************************************************************************/
void ADC_voidInit (void);
/************************************************************************************************/
/* Function Name : ADC_u16GetReading                                                            */
/* Description : Get Analog Reading From ADC & DAC                                              */
/* Fun. Argument1: Copy_u8ChannelNumber { ADC0,ADC1,ADC2,ADC3,ADC4,ADC5,ADC6,ADC7 }             */
/* Fun. Return : u16                                                                            */
/************************************************************************************************/
uint16 ADC_u16GetReading ( uint8 Copy_u8ChannelNumber );

#endif
