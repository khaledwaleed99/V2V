/*=================================================================================*/
/*  File        : ADC_Program.c                                                    */
/*  Description : This file includes ADC Driver implementations for Atmega32       */
/*  Author      : Mona Elsaied                                                     */
/*  Date        : 20/10/2023                                                       */
/*=================================================================================*/

/* Include Header Files From LIB */
#include "../../LIB/STD_TYPES.h"
#include "../../LIB/BIT_MATH.h"
#include "../../LIB/ATMEGA_128_REGS.h"

/* Include Header Files From MCAL */
#include "../../MCAL/DIO/DIO_PROTOTYPES.h"
#include "ADC_CONFIG.h"
/* Include My own Header Files*/
#include "ADC_PROTOTYPES.h"


/************************************************************************************************/
/* Function Name : ADC_voidInit                                                                 */
/* Description : Initilization of ADC with Specific Specs accordig to Gonfigration File.h       */
/* Fun. Return : void                                                                           */
/************************************************************************************************/
void ADC_voidInit (void)
{
/*======================================*/
/*       Select Reference Voltage       */ 
/*--------------------------------------*/
    #if ( REFERENCE_VOLTAGE == AREF )
	CLR_BIT(ADMUX,6);
	CLR_BIT(ADMUX,7);
    #elif ( REFERENCE_VOLTAGE == AVCC )
        SET_BIT(ADMUX,6);
        CLR_BIT(ADMUX,7);
    #elif ( REFERENCE_VOLTAGE == INTERNAL )
        SET_BIT(ADMUX,6);
        SET_BIT(ADMUX,7);
    #else
        CLR_BIT(ADMUX,6);
        SET_BIT(ADMUX,7);
    #endif
/*======================================*/
/*     Select RIGHT or LEFT Adjust      */
/*--------------------------------------*/
    #if ( ADJUST == RIGHT )
        CLR_BIT(ADMUX,5);
    #elif ( ADJUST == LEFT )
        SET_BIT(ADMUX,5);
    #endif
/*======================================*/
/*        ADC Enable or Disable         */
/*--------------------------------------*/
    #if ( ADEN == ENABLE )
        SET_BIT(ADCSRA,7);
    #elif ( ADEN == DISABLE )
        CLR_BIT(ADCSRA,7);
    #endif
/*======================================*/
/*    AUTO Trigger Enable or Disable    */
/*--------------------------------------*/
    #if ( ADATE == ENABLE )
        SET_BIT(ADCSRA,5);
            /*======================================*/ 
            /*       ADC Auto Trigger Source        */
            /*--------------------------------------*/
        #if( AUTO_TRIGGER_SOURCE == Free_Running_Mode )
        CLR_BIT(SFIOR_REG,5);
        CLR_BIT(SFIOR_REG,6);
        CLR_BIT(SFIOR_REG,7);
        #elif ( AUTO_TRIGGER_SOURCE == Analog_Comparator )
              SET_BIT(SFIOR_REG,5);
              CLR_BIT(SFIOR_REG,6);
              CLR_BIT(SFIOR_REG,7);
        #elif ( AUTO_TRIGGER_SOURCE == External_Interrupt_Request_0 )
              CLR_BIT(SFIOR_REG,5);
              SET_BIT(SFIOR_REG,6);
              CLR_BIT(SFIOR_REG,7);
        #elif ( AUTO_TRIGGER_SOURCE == Timer_Counter0_Compare_Match )
              SET_BIT(SFIOR_REG,5);
              SET_BIT(SFIOR_REG,6);
              CLR_BIT(SFIOR_REG,7);
        #elif ( AUTO_TRIGGER_SOURCE == Timer_Counter0_Overflow )
              CLR_BIT(SFIOR_REG,5);
              CLR_BIT(SFIOR_REG,6);
              SET_BIT(SFIOR_REG,7);
        #elif ( AUTO_TRIGGER_SOURCE == Timer_Counter1_Compare_MatchB )
              SET_BIT(SFIOR_REG,5);
              CLR_BIT(SFIOR_REG,6);
              SET_BIT(SFIOR_REG,7);
        #elif ( AUTO_TRIGGER_SOURCE == Timer_Counter1_Overflow )
              CLR_BIT(SFIOR_REG,5);
              SET_BIT(SFIOR_REG,6);
              SET_BIT(SFIOR_REG,7);
        #elif ( AUTO_TRIGGER_SOURCE == Timer_Counter1_Capture_Event )
              SET_BIT(SFIOR_REG,5);
              SET_BIT(SFIOR_REG,6);
              SET_BIT(SFIOR_REG,7);
        #endif

    #elif ( ADATE == DISABLE )
              CLR_BIT(ADCSRA,5);
    #endif
/*======================================*/
/*    ADC Interrupt Enable or Disable   */
/*--------------------------------------*/
    #if ( ADIE == ENABLE )          // work with Interrupt
        SET_BIT(ADCSRA,3);
    #elif ( ADIE == DISABLE )       // work with Polling
        CLR_BIT(ADCSRA,3);
    #endif
/*======================================*/
/*       ADC Prescaler Selection        */
/*--------------------------------------*/
    /*     Clear Prescaler      */ 
        ADCSRA = ( ADCSRA & 0b11111000 );

    #if( PRESCALER == NOT_USE_PRESCALER )
        // NOTHING
    #elif ( PRESCALER == PRESCALER_DIVISION_BY_2 )
          SET_BIT(ADCSRA,0);
          CLR_BIT(ADCSRA,1);
          CLR_BIT(ADCSRA,2);
    #elif ( PRESCALER == PRESCALER_DIVISION_BY_4 )
          CLR_BIT(ADCSRA,0);
          SET_BIT(ADCSRA,1);
          CLR_BIT(ADCSRA,2);
    #elif ( PRESCALER == PRESCALER_DIVISION_BY_8 )
          SET_BIT(ADCSRA,0);
          SET_BIT(ADCSRA,1);
          CLR_BIT(ADCSRA,2);
    #elif ( PRESCALER == PRESCALER_DIVISION_BY_16 )
          CLR_BIT(ADCSRA,0);
          CLR_BIT(ADCSRA,1);
          SET_BIT(ADCSRA,2);
    #elif ( PRESCALER == PRESCALER_DIVISION_BY_32 )
          SET_BIT(ADCSRA,0);
          CLR_BIT(ADCSRA,1);
          SET_BIT(ADCSRA,2);
    #elif ( PRESCALER == PRESCALER_DIVISION_BY_64 )
          CLR_BIT(ADCSRA,0);
          SET_BIT(ADCSRA,1);
          SET_BIT(ADCSRA,2);
    #elif ( PRESCALER == PRESCALER_DIVISION_BY_128 )
          SET_BIT(ADCSRA,0);
          SET_BIT(ADCSRA,1);
          SET_BIT(ADCSRA,2);
    #endif
/*======================================*/
}
/************************************************************************************************/
/* Function Name : ADC_u16GetReading                                                            */
/* Description : Get Analog Reading From ADC & DAC                                              */
/* Fun. Argument1: Copy_u8ChannelNumber { ADC0,ADC1,ADC2,ADC3,ADC4,ADC5,ADC6,ADC7 }             */
/* Fun. Return : u16                                                                            */
/************************************************************************************************/
uint16 ADC_u16GetReading ( uint8 Copy_u8ChannelNumber )
{
/*===============================================================================================*/
    /*     Clear MUX      */ 
	ADMUX = ( ADMUX & 0b11100000 );
/*===============================================================================================*/
    /*   Select channel   */ 
    switch ( Copy_u8ChannelNumber )
    {
        case ADC0 :     ADMUX = (( ADMUX & 0b11100000 ) | 0b00000000 );     break;
        case ADC1 :     ADMUX = (( ADMUX & 0b11100000 ) | 0b00000001 );     break;
        case ADC2 :     ADMUX = (( ADMUX & 0b11100000 ) | 0b00000010 );     break;
        case ADC3 :     ADMUX = (( ADMUX & 0b11100000 ) | 0b00000011 );     break;
        case ADC4 :     ADMUX = (( ADMUX & 0b11100000 ) | 0b00000100 );     break;
        case ADC5 :     ADMUX = (( ADMUX & 0b11100000 ) | 0b00000101 );     break;
        case ADC6 :     ADMUX = (( ADMUX & 0b11100000 ) | 0b00000110 );     break;
        case ADC7 :     ADMUX = (( ADMUX & 0b11100000 ) | 0b00000111 );     break;
        default   :                                                                 break;
    }
/*===============================================================================================*/  
    /*    Start Conversion    */ 
    #if ( ADATE == ENABLE )
        // Start Conversion When Triggering Occures.
    #elif ( ADATE == DISABLE )
        SET_BIT(ADCSRA,6);
    #endif
/*===============================================================================================*/    
    #if ( ADIE == ENABLE )                        // work with Interrupt
        // When ADC Finish conversion will Raising Interrupt Flag and Jump to ADC_ISR Function.    
    #elif ( ADIE == DISABLE )                     // work with Polling
        /* GET FLAG and Polling the Flag */
        uint8 ADIF=0 ;
        while( ADIF == 0 )
        {
            ADIF = GET_BIT(ADCSRA,4);    // Stuck on while untill Flag Raising 1 .
        }
    #endif
/*===============================================================================================*/
    #if ( ADIE == ENABLE )          // work with Interrupt
        // Interrupt Flag Will Cleared Automaticlly.    
    #elif ( ADIE == DISABLE )       // work with Polling
        /* Clear Flag */
        SET_BIT(ADCSRA,4);
    #endif 
/*==========================================================================================================================*/
/*********************************************************     Get Reading      *********************************************/
/*        Get Reading from 16 Bit ADC_REG  if we used RIGHT Adjust and Resoluotion 10 BIT  Return Value From { 0 -> 1023 }  */
/*        Get Reading from 8 Bit ADCH_REG  if we used LEFT Adjust and Resoluotion  8 BIT   Return Value From { 0 -> 255  }  */
/*--------------------------------------------------------------------------------------------------------------------------*/
    #if ( ADJUST == RIGHT )
        return ADC_ADJUST ;
    #elif ( ADJUST == LEFT )
        return ADCH_REG ;
    #endif
/*===============================================================================================*/

        //  Analog_Signal = Digital_Signal *  Step Size
        //  Analog_Signal = Digital_Signal * ( V max / 2^Rsolution )  // Rsolution =10 BIT & Vmax = 5v 
        //  Analog_Signal = Digital_Signal * ( 5 / 2^10 ) 

/*===============================================================================================*/


}
