
#include "../../LIB/STD_TYPES.h"
#include "../../LIB/BIT_MATH.h"
#include "../../LIB/ATMEGA_128_REGS.h"
#include "GIE_CONFIG.h"

#include "GIE_PROTOTYPES.h"

void GIE_voidEnableInterruptGlobal (void)
{
     SET_BIT(SREG , 7);
}

void GIE_voidDisableInterruptGlobal (void)
{
	 CLR_BIT(SREG , 7);
}
