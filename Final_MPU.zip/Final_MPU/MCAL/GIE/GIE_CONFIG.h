/*
 * GIE_Config.h
 *
 *  Created on: Apr 3, 2023
 *      Author: DeLL
 */

#ifndef MCAL_GIE_GIE_CONFIG_H_
#define MCAL_GIE_GIE_CONFIG_H_



#endif /* MCAL_GIE_GIE_CONFIG_H_ */
