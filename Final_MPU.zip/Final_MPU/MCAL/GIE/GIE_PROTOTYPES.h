/*
 * GIE_Interface.h
 *
 *  Created on: Apr 3, 2023
 *      Author: DeLL
 */

#ifndef MCAL_GIE_GIE_PROTOTYPES_H_
#define MCAL_GIE_GIE_PROTOTYPES_H_

void GIE_voidEnableInterruptGlobal (void);

void GIE_voidDisableInterruptGlobal (void);

#endif /* MCAL_GIE_GIE_PROTOTYPES_H_ */
