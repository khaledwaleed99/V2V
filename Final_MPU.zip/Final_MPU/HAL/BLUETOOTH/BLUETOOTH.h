/*
 * BLUETOOTH.h
 *
 *  Created on: Dec 5, 2023
 *      Author: DeLL
 */

#ifndef HAL_BLUETOOTH_BLUETOOTH_H_
#define HAL_BLUETOOTH_BLUETOOTH_H_



void Blu0_Init(uint16 baudRate);
void Blu0_TransmitChr(uint8 data);
uint8 Blu0_ReceiveChr(void);
void Blu0_TransmitStrPoll(uint8 str);

#endif /* HAL_BLUETOOTH_BLUETOOTH_H_ */
