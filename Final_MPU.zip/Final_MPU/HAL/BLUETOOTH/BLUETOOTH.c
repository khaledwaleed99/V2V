/*
 * BLUETOOTH.c
 *
 *  Created on: Dec 5, 2023
 *      Author: DeLL
 */


#include "../../LIB/STD_TYPES.h"
#include "../../MCAL/UART/UART_PROTOTYPES.h"
#include "BLUETOOTH.h"


void Blu0_Init(uint16 baudRate)
{
	UART0_Init(baudRate);
}
void Blu0_TransmitChr(uint8 data)
{
	UART0_TransmitChr(data);

}
uint8 Blu0_ReceiveChr(void)
{
	uint8 chr;
	chr =UART0_ReceiveChr();
	return chr;
}
void Blu0_TransmitStrPoll(uint8 str)
{
	UART0_TransmitStrPoll(&str);
}

