/**********************************************************************************************************************/
/**********************************************************************************************************************/
/*****************		Author:  Omar Yahya		***********************************************************************/
/*****************		Layer:	 HAL			***********************************************************************/
/*****************		SWC:	 UltraSonic		***********************************************************************/
/*****************		File:	 Program        ***********************************************************************/
/**********************************************************************************************************************/
/**********************************************************************************************************************/

/**********************************************************************************************************************
 *  INCLUDES
 **********************************************************************************************************************/
#include <util/delay.h>
#include "../../LIB/STD_TYPES.h"
#include "../../LIB/ERROR_STATES.h"
#include "../../MCAL/DIO/DIO_PROTOTYPES.h"
#include "../../MCAL/ICU/ICU_PROTOTYPES.h"
#include "ULTRASONIC_CONFIG.h"
#include "ULTRASONIC_PRIVATE.h"
#include "ULTRASONIC_PROTOTYPES.h"
/**********************************************************************************************************************
 *  LOCAL DATA
 **********************************************************************************************************************/

/**********************************************************************************************************************
 *  GLOBAL DATA
 **********************************************************************************************************************/
ICU_t Global_enICU;
uint16 Global_u16Reading1 = 0;
uint16 Global_u16Reading2 = 0;
uint16 Global_u16Ticks;
f32 Global_f32Time;
uint16 Global_u16Distance;
/**********************************************************************************************************************
 *  LOCAL FUNCTIONS
 **********************************************************************************************************************/
static void ULTRASONIC_voidCallBackICU() {
	static uint8 Local_u8Counter = 0;
	Local_u8Counter++;
	if (Local_u8Counter == 1) {
		MICU_enReadICR(Global_enICU, &Global_u16Reading1);
		MICU_enEdgeSelect(Global_enICU, FALLING);
	} else if (Local_u8Counter == 2) {
		MICU_enReadICR(Global_enICU, &Global_u16Reading2);
		MICU_enEdgeSelect(Global_enICU, RISING);
		Local_u8Counter = 0;
	}
}
/**********************************************************************************************************************
 *  GLOBAL FUNCTIONS
 **********************************************************************************************************************/
ErrorState_t ULTRASONIC_enInit(ICU_t copy_enICU, DIO_PORT_ID PORT_ID,  DIO_PIN_ID PIN_ID) {
	ErrorState_t Local_enState = SUCCESS;
	/** Set Trigger Pin as Output **/
	DIO_SET_PIN_DIREC(PORT_ID, PIN_ID, DIO_OUTPUT);
	/** Set Echo Pin as Input **/
	if (copy_enICU == ICU1) {
		DIO_SET_PIN_DIREC(ICP1_PIN, DIO_INPUT);
	} else if (copy_enICU == ICU3) {
		DIO_SET_PIN_DIREC(ICP3_PIN, DIO_INPUT);
	} else {
		Local_enState = OUT_OF_RANGE;
	}
	MICU_enSetCallBack(copy_enICU, ULTRASONIC_voidCallBackICU);
	MICU_enInterruptEnable(copy_enICU);
	MICU_enInit(copy_enICU);
	return Local_enState;
}

ErrorState_t ULTRASONIC_enGetReading(ICU_t copy_enICU, DIO_PORT_ID PORT_ID,  DIO_PIN_ID PIN_ID, uint16 *ptrDistance) {
	ErrorState_t Local_enState = SUCCESS;
	if (ptrDistance == NULL) {
		Local_enState = NULL_POINTER;
	} else {
		/** Move the ICU source to Pass it to Callback Function **/
		Global_enICU = copy_enICU;
		/** Send Trigger Pulse **/
		DIO_SET_PIN_VALUE(PORT_ID, PIN_ID, DIO_HIGH);
		_delay_us(10);
		DIO_SET_PIN_VALUE(PORT_ID, PIN_ID, DIO_LOW);
		/** Busy Waiting until all Reading finished **/
		while (Global_u16Reading2 == 0)
			;
		Global_u16Ticks = Global_u16Reading2 - Global_u16Reading1;

		Global_f32Time = (f32) Global_u16Ticks * ((f32) ICU_PRESCALER / (f32) PRESCALER_256) ;
		*ptrDistance = Global_f32Time*2 / 58.0;
		/** Return Global Reading to its Initial Value to Busy wait again if this function called again **/
		Global_u16Reading1 = 0;
		Global_u16Reading2 = 0;
	}
	return Local_enState;
}
