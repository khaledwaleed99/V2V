/**********************************************************************************************************************/
/**********************************************************************************************************************/
/*****************		Author:  Omar Yahya		***********************************************************************/
/*****************		Layer:	 HAL			***********************************************************************/
/*****************		SWC:	 UltraSonic		***********************************************************************/
/*****************		File:	 Interface      ***********************************************************************/
/**********************************************************************************************************************/
/**********************************************************************************************************************/

#ifndef ULTRASONIC_PROTOTYPES_H_
#define ULTRASONIC_PROTOTYPES_H_

/**********************************************************************************************************************
 * SHAREABLE MACROS
 **********************************************************************************************************************/

/**********************************************************************************************************************
 * USER DEFINED DATA TYPES
 **********************************************************************************************************************/

/**********************************************************************************************************************
 * GLOBAL FUNCTIONS PROTOTYPES
 **********************************************************************************************************************/

/**
 * Input:  		 1- ICU Select:
 * 				 	- ICU1
 * 				 	- ICU3
 * 				 2- Pin select for Trigger from PA0 to PG4
 * Output: 		 No Output
 * In/Out: 		 No In/Out
 * Description:  This function Initialize the UltraSonic by:
 * 				 	- Set Trigger Pin as Output
 * 				 	- Set Echo Pin as Input
 * 				 	- Set Callback for ICU
 * 				 	- Enable the ICU Interrupt
 * 				 	- Initialize the ICU
 * Pre-request:	 Enable GIE after calling this function
 */
ErrorState_t ULTRASONIC_enInit(ICU_t copy_enICU, DIO_PORT_ID PORT_ID,  DIO_PIN_ID PIN_ID);
;

/**
 * Input:  		 1- ICU Select:
 * 				 	- ICU1
 * 				 	- ICU3
 * 				 2- Pin select for Trigger from PA0 to PG4
 * Output: 		 The Measured Distance
 * In/Out: 		 No In/Out
 * Description:  This function Get the Reading from the UltraSonic
 */
ErrorState_t ULTRASONIC_enGetReading(ICU_t copy_enICU, DIO_PORT_ID PORT_ID,  DIO_PIN_ID PIN_ID, uint16 *ptrDistance);

#endif
