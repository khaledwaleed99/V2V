/*
 * MPU6050.c
 *
 * Created: 1/26/2020 7:39:57 PM
 * Author : Abdelaziz
 */ 

#include "HAL/MPU/MPU6050.h"
#include "HAL/LCD/lcd.h"

volatile MPU6050_Data Live_Data;
int main(void)
{
	LCD_init();											  	 /* Initialize the LCD */
	I2C_Init();												 /* Initialize I2C */


	MPU6050_Init(_8KHz_Fs,Gyro_Xaxsis_Ref,_1KHz_SampleRate); /* Initialize MPU6050 */
    while (1) 
    {

//
    	MPU6050_READ(&Live_Data);
    	LCD_clearScreen();
		LCD_displayString("Ax=");
		LCD_intgerToString((uint16) (Live_Data.Acc_x));
		LCD_displayString("  Ay=");
		LCD_intgerToString((uint16) (Live_Data.Acc_y));
		LCD_moveCursor(1,0);
		LCD_displayString("Az=");
		LCD_intgerToString((uint16) (Live_Data.Acc_z));
		LCD_moveCursor(2,0);
		LCD_displayString("Gx=");
		LCD_intgerToString((uint16) (Live_Data.Gyro_x));
		LCD_displayString("  Gy=");
		LCD_intgerToString((uint16) (Live_Data.Gyro_y));
		LCD_moveCursor(3,0);
		LCD_displayString("Gz=");
		LCD_intgerToString((uint16) (Live_Data.Gyro_z));
		LCD_displayString("  Temp=");
		LCD_intgerToString((uint16) (Live_Data.Temperature));
		_delay_ms(5000);
		LCD_clearScreen();
		LCD_displayString("Updating ..");
		_delay_ms(5000);
    }
}

