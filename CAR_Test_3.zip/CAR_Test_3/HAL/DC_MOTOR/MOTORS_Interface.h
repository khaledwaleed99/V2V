

#ifndef MOTORS_INTERFACE_H_
#define MOTORS_INTERFACE_H_


/*
* NOTE THAT: this driver used only for dc motor with H bridge L 293D
*/



typedef enum{
	M1,
	M2,
	M3,
	M4
}MOTOR_type;


void MOTOR_Init(void);

void MOTOR_Stop(MOTOR_type m);

void MOTOR_CW(MOTOR_type m);

void MOTOR_CCW(MOTOR_type m);



/*car movement */

void CAR_FW(void);

void CAR_BW(void);

void CAR_R(void);

void CAR_L(void);

void CAR_STOP(void);

#endif /* MOTORS_INTERFACE_H_ */