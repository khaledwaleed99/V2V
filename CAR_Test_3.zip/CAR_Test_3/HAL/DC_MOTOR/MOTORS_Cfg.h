/*
 * MOTORS_Cfg.h
 *
 * Created: 11/18/2023 10:05:28 AM
 *  Author: IT
 */ 



/* u can use port A,B,C,D only for atmega 128*/
#ifndef MOTORS_CFG_H_
#define MOTORS_CFG_H_



/*M1 */
#define  M1_IN1_PIN   DIO_PIN2
#define  M1_IN2_PIN   DIO_PIN3

#define  M1_IN1_PORT   DIO_PORTD
#define  M1_IN2_PORT   DIO_PORTD

/*M2 */
#define  M2_IN1_PIN   DIO_PIN3
#define  M2_IN2_PIN   DIO_PIN2

#define  M2_IN1_PORT   DIO_PORTA
#define  M2_IN2_PORT   DIO_PORTA

/*M3 */
#define  M3_IN1_PIN   DIO_PIN4
#define  M3_IN2_PIN   DIO_PIN5
		  
#define  M3_IN1_PORT   DIO_PORTD
#define  M3_IN2_PORT   DIO_PORTD

/*M4 */
#define  M4_IN1_PIN   DIO_PIN0
#define  M4_IN2_PIN   DIO_PIN1
		  
#define  M4_IN1_PORT   DIO_PORTA
#define  M4_IN2_PORT   DIO_PORTA




#endif /* MOTORS_CFG_H_ */
