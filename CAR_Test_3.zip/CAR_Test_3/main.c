#include "MCAL/DIO/DIO_PROTOTYPES.h"


#include "HAL/DC_MOTOR/MOTORS_Interface.h"
#include "HAL/BLUETOOTH/BLUETOOTH.h"
//#define F_CPU 8000000
#include <util/delay.h>

#define IDLE '0'
#define MOVE_FORWARD  'a'
#define MOVE_BACKWARD 'c'
#define MOVE_RIGHT    'b'
#define MOVE_LEFT     'd'
#define STOP          's'

int main(void) {

	uint8 Local_u8Data = IDLE;
	/**  Deactivate 7 Segment **/
	DIO_SET_PIN_VALUE(DIO_PORTF, DIO_PIN2, DIO_HIGH);
	//	/** Set Motor Direction **/
	//	DIO_SET_PORT_DIREC(DIO_PORTA, DIO_OUTPUT);
	//	DIO_SET_PORT_DIREC(DIO_PORTG, DIO_OUTPUT);
	/** UART Direction **/
	DIO_SET_PIN_DIREC(DIO_PORTE, DIO_PIN0, DIO_INPUT);
	DIO_SET_PIN_DIREC(DIO_PORTE, DIO_PIN1, DIO_OUTPUT);

	Blu0_Init(9600);
	MOTOR_Init();

	while (1) {

		Local_u8Data = Blu0_ReceiveChr();
		switch (Local_u8Data) {
		case MOVE_FORWARD:

			CAR_FW();
			Local_u8Data = IDLE;
			break;
		case MOVE_BACKWARD:
			CAR_BW();
			Local_u8Data = IDLE;
			break;
		case MOVE_LEFT:
			CAR_L();
			break;
		case MOVE_RIGHT:
			CAR_R();
			break;
		case STOP:
			CAR_STOP();
			Local_u8Data = IDLE;
			break;
		default:

			break;
		}
	}

	return 0;
}
